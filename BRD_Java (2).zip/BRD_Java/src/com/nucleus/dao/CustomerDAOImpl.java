package com.nucleus.dao;
import java.util.ArrayList;
import java.util.List;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connection.CreateConnection;
import com.nucleus.domain.CustomerM;
import com.nucleus.errorlog.ErrorLog;
import com.nucleus.validation.ValidationClass;

public class CustomerDAOImpl implements CustomerDAO{
	PreparedStatement preparedStatement=null;
	BufferedReader bufferedReader=null; 
	CreateConnection createConnection = new CreateConnection();
	Connection conn = createConnection.ConnectionClass();
	//readfromfile method return type list of customers
	static int count=0;
	public void readFromFile(String loc,int rej){

FileReader fileReader =null;
BufferedReader bufferedReader=null; 
CustomerM customerM =new CustomerM();
ValidationClass validationClass= new ValidationClass();
ErrorLog errorLog= new ErrorLog();
Boolean a=false;
int errorCount=0;

try{ 
	fileReader= new FileReader(loc);
	bufferedReader = new BufferedReader(fileReader);
	String str1 = bufferedReader.readLine();
	while (str1 !=null)
	{
		String str[]=str1.split("~",-1);
		/////////////////////////////////////////////////////////
		//Validation CustomerCode
		if(validationClass.nullCheck(str[0])&&( str[0].length()<=10) ){
			customerM.setCustomerCode(str[0]);
		
		
		}
		else{
			//System.out.println("1");
			//System.out.println(errorCount+""+str[0]);
			errorCount++;
		}
		
			
		
		///////////////////////////////////////////////////////////
		//Validation CustomrName
		int len=str[1].length();
		if(validationClass.customerNameValidation(str[1]) && (len<=30)){
			//System.out.println("2");
			customerM.setCustomerName(str[1]);
		}
		else{
			//System.out.println(errorCount+""+str[1]);
			errorCount++;
		}
		///////////////////////////////////////////////////////
		//Validation CustomerAddress 1
		len=str[2].length();
		if(validationClass.nullCheck(str[2])&& (len<=100))	
		{
			customerM.setCustomerAdd1(str[2]);
			
		}
		else {
			//System.out.println("3");
			//System.out.println(errorCount+""+str[2]);
			errorCount++;
		}
		////////////////////////////////////////////////
		//Validation CustomerAddress 2
		if(str[3].length()<=100)
		{
			//System.out.println("4");
			customerM.setCustomerAdd2(str[3]);	
		}
		else{
			//System.out.println(errorCount+""+str[3]);
			errorCount++;
			}
		//////////////////////////////////////////////////////////
		//Validation CustomerPinCode
		len=str[4].length();
		if(validationClass.fieldLengthValidation((Long.parseLong(str[4])))&& len<=6)
				{
			//System.out.println("5");
			customerM.setCustomerPinCode(Long.parseLong(str[4]));	
		        }
		else{
			//System.out.println(errorCount+""+str[4]);
		errorCount++;
		}
		///////////////////////////////////////////////
		//Validation CustomerEmail Address
		len=str[5].length();
		if(validationClass.emailValidation(str[5])&&(len<=100)){
			//System.out.println("6");
			customerM.setEmailAdd(str[5]);
		}
		else{
			//System.out.println(errorCount+""+str[5]);
			errorCount++;
		}
		//////////////////////////////////////////////////
		//Validation Customer Contact Number
		if(str[6].length()<=20)
				{
			//System.out.println("7");
			customerM.setContact_Number(Long.parseLong(str[6]));	
		}
		else{
			//System.out.println(errorCount+""+str[6]);
			errorCount++;
		}
	//////////////////////////////////////////////////////////	
		//Validation PrimaryContactPerson
		len=str[7].length();
		if(validationClass.nullCheck(str[7])&&(len<=100)){
			customerM.setPrimaryContactPerson(str[7]);
			
		}
		else{
			//System.out.println("8");
			//System.out.println(errorCount+""+str[7]);
			errorCount++;
		}
		////////////////////////////////////////////////////////
		//Validation Record Status
		len=str[8].length();
		if(validationClass.recordStatusValidation(str[8])&&(len<=1))
		{
			//System.out.println("9");
			customerM.setRecordStatus(str[8]);
		}
		else{
			//System.out.println(errorCount+""+str[8]);
			errorCount++;
		}
		//////////////////////////////////////////////////////
		//Validation Flag
		len=str[9].length();
		if(validationClass.flagValidation(str[9])&&(len<=1)){
			//System.out.println("10");
			customerM.setFlag(str[9]);	
		}
		else{
			//System.out.println(errorCount+""+str[9]);
			errorCount++;
		}
		/////////////////////////////////////////////////////////
		//Validation Create Date
		if(validationClass.nullCheck(str[10]))
		{
			customerM.setCreateDate(str[10]);
			
		}
		else{
			//System.out.println("11");
			//System.out.println(errorCount+""+str[10]);
			errorCount++;
		}
		
		/////////////////////////////////////////////////////////////
		//Validation Create BY
		len=str[11].length();
		if(validationClass.nullCheck(str[11])&&(len<=30))
		{
			customerM.setCreatedBy(str[11]);
		
		}
		else{
			//System.out.println("12");
			//System.out.println(errorCount+""+str[11]);
			errorCount++;
		}
		////////////////////////////////////////////////////
		//Validation Modified date
		//System.out.println("13");
		customerM.setModifiedDate(str[12]);
		
		/////////////////////////////////////////////////
		//Validation Modified BY
		len=str[13].length();
		if(len<=30){
			//System.out.println("14");
			customerM.setModifiedBy(str[13]);
		}
		else{
			//System.out.println(errorCount+""+str[13]);
			errorCount++;
		}
		///////////////////////////////////////////////
		//Validation AuthorisedDate
		//System.out.println("15");
		customerM.setAuthorisedDate(str[14]);
		////////////////////////////////////////
		//Validation Authorised BY
		len=str[15].length();
		if(str[15].length()<=30){
			//System.out.println("16");
		customerM.setAuthorisedBy(str[15]);
		}
		else{
			//System.out.println(errorCount+""+str[15]);
			errorCount++;
		}
		///////////////////////////////////////////
		//System.out.println("errror "+errorCount);
		//Check for Rejection Level Inputs
		
		if(errorCount==0){
			insertIntoDatabase(customerM);
			str1 = bufferedReader.readLine();
			
		}
		
		else {
			if(rej==1){
				
				errorLog.saveToFile(str1);
				str1=bufferedReader.readLine();
				errorCount=0;
			}
			else{
				errorLog.copyfile(loc);//
				PreparedStatement preparedStatement; 
				try{
					preparedStatement =conn.prepareStatement("delete from mytable121");
					preparedStatement.executeUpdate(); 
					
				}
				catch (SQLException e){
					e.printStackTrace();
				}
				System.exit(0);
					
			}
			
		}
}

	
	
		

		
	}
catch (FileNotFoundException e) {
e.printStackTrace();
} catch (IOException e) {

e.printStackTrace();
} catch (Exception e) {

e.printStackTrace();
}
	
finally {
	
	try {

		bufferedReader.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
	} 
	
	
	
	public void insertIntoDatabase(CustomerM customerM){
		
		
		try {
			preparedStatement = conn.prepareStatement("insert into mytable121 values(s121.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1, customerM.getCustomerCode());
			preparedStatement.setString(2, customerM.getCustomerName() );
			preparedStatement.setString(3, customerM.getCustomerAdd1() );
			preparedStatement.setString(4, customerM.getCustomerAdd2() );
			preparedStatement.setLong(5, customerM.getCustomerPinCode() );
			preparedStatement.setString(6, customerM.getEmailAdd());
			preparedStatement.setLong(7, customerM.getContact_Number() );
			preparedStatement.setString(8, customerM.getPrimaryContactPerson());
			preparedStatement.setString(9, customerM.getRecordStatus());
			preparedStatement.setString(10,customerM.getFlag() );
			preparedStatement.setString(11, customerM.getCreateDate() );
			preparedStatement.setString(12, customerM.getCreatedBy() );
			preparedStatement.setString(13, customerM.getModifiedDate() );
			preparedStatement.setString(14, customerM.getModifiedBy());
			preparedStatement.setString(15, customerM.getAuthorisedDate() );
			preparedStatement.setString(16, customerM.getAuthorisedBy());
			preparedStatement.executeUpdate();
			
			System.out.println(count++);
		} catch (SQLException e) {
			
			System.out.println("err");
		} 
		
		
		
		
	}
	
	
	
	
	
	
	
}

		
		
		
	
	
	

