package com.nucleus.dao;

import java.util.List;

import com.nucleus.domain.CustomerM;



public interface CustomerDAO {
public void readFromFile(String location,int Rejection);

}
