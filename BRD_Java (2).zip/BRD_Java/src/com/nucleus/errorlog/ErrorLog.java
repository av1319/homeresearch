package com.nucleus.errorlog;

import java.io.*;

public class ErrorLog {

	public void saveToFile(String line){
		FileWriter fileWriter=null;
		PrintWriter printWriter=null;
		
		try {
			fileWriter = new FileWriter("Errorlog1.txt",true);
			printWriter = new PrintWriter (fileWriter);
			printWriter.write(line+"\n");
			printWriter.flush();	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		finally{
			try {
				fileWriter.close();
				printWriter.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		 
		
		
		
		
	}
	
	
	
	
	public void copyfile(String loc){
		
		FileReader fileReader=null;
		BufferedReader bufferedReader=null;
		
		try {
			fileReader= new FileReader(loc);
			bufferedReader= new BufferedReader(fileReader);
			
			String line=bufferedReader.readLine();
			
			while(line!=null){
				
				saveToFile(line);
				line= bufferedReader.readLine();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally{
			try {
				fileReader.close();
				bufferedReader.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
	}
	
	
	
	
}
