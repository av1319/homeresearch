package execution;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.nucleus.dao.CustomerDAO;
import com.nucleus.dao.CustomerDAOImpl;
import com.nucleus.domain.CustomerM;
import com.nucleus.validation.ValidationClass;


public class Execution1 {

	public static void main(String[] args) {
		
		CustomerM customerM = new CustomerM();
		CustomerDAO c = new CustomerDAOImpl();
		Scanner sc= new Scanner (System.in);
		
		System.out.println("Enter File Location");
		String loc=sc.nextLine();
		
		int temp=1;
		String location=null;
		while(temp==1){
			
			System.out.println("Enter your File Name");
			String fileName=sc.nextLine();
			if(fileName.endsWith(".txt")){
				 location=loc.concat(("//"+fileName));
				temp=2;
			}
			else {
				System.out.println("Enter file with .txt Extension");
			}
		}
		
System.out.println(" Enter Rejection Level:\n1 for Record Level Rejection \n2 for  File Level Rejection ");
int rejection=sc.nextInt();

   c.readFromFile(location,rejection);
//   ValidationClass validationClass = new ValidationClass();

   
   	
	}

}
